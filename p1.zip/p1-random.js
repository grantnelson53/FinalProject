/* 
    CIS 281 - Project 1
    Name - Grant Nelson 
*/

function getRandomInteger(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

let letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];

function randomString() {
    let stringer = '';
    for (i = 0; i <= (getRandomInteger(5,26)); i++) {
        stringer = stringer + letters[getRandomInteger(0,26)];
    }

    return stringer;
}

console.log(randomString());